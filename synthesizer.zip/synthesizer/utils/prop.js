class Prop{
    constructor(){}
}
module.exports=Prop;