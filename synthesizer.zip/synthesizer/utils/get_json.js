var fs = require("fs");
var basePath = process.cwd();
var Prop = require('./prop');

const description = 'lizardmen# for test';
const prefix_name = '';
const img = 'QmfEoyAG694V7vUWPMMQ6QZzRaevCXjnTt6KeuszUNFYYm';

const nft_json = './nft_json/';

if (fs.existsSync(`${nft_json}`)) {
  let files = fs.readdirSync(`${nft_json}`);
  files.forEach(p => {
    fs.unlinkSync(`${nft_json}` + p);
  })
} else {
  fs.mkdirSync(`${nft_json}`);
}

fs.readdir('./nft', (err, files) => {
  if (!err) {
    files.forEach(p => {
      let fn = p.split('.')[0] + '.json';
      let jd = (()=>{
        let prop = new Prop();
        prop.name =`${prefix_name}` + fn;
        prop.description = `${description}`;
        prop.image = `ipfs://${img}/` + p;
        return JSON.stringify(prop);
      })();
      console.log(p);
      fs.writeFile(`${nft_json}` + fn, jd, err => {
        if (err) {
          console.log(err);
        }
      });
    });
  }
});